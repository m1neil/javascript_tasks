'use strict'

// З клавіатури вводиться число. Знаходити суму цифр до тих пір. Поки сума не стане більшую за 20.

// Написати програму виведення на екран кожного символу латинського алфавіту та поруч з кожним з них символу, що передує йому та що слідує за ним.

const start = 65, end = 90
const output = document.querySelector('.page__container')

for (let i = start; i <= end; i++) {
	if (i === start)
		output.insertAdjacentHTML('beforeend',
			`<div>Попереднього немає, ${String.fromCharCode(i)}, ${String.fromCharCode(i + 1)}</div>`)
	else if (i === end)
		output.insertAdjacentHTML('beforeend',
			`<div>${String.fromCharCode(i - 1)}, ${String.fromCharCode(i)}, Наступного немає,</div>`)
	else
		output.insertAdjacentHTML('beforeend',
			`<div>${String.fromCharCode(i - 1)}, ${String.fromCharCode(i)}, ${String.fromCharCode(i + 1)}</div>`)
}	